package com.example.neurovoiceoffline

import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

object TtsEngine {
    fun generate(
        modelDir: File,
        text: String,
        speed: Float,
        pauseMs: Int,
        output: File
    ): File {
        val model = modelDir.walkTopDown().firstOrNull { it.extension.equals("onnx", ignoreCase = true) }
            ?: error("Не найден ONNX-файл голосовой модели")
        val tokens = modelDir.walkTopDown().firstOrNull { it.name == "tokens.txt" }
            ?: error("Не найден tokens.txt")
        val dataDir = modelDir.walkTopDown().firstOrNull { it.name == "espeak-ng-data" }
            ?: error("Не найден espeak-ng-data")

        // Sherpa-ONNX 1.13.x exposes Kotlin data classes, not Java-style setters.
        // Build the configuration through constructors to avoid unresolved
        // setModel/setTokens/setDataDir/setMaxNumSentences/setSpeed/etc.
        val vits = OfflineTtsVitsModelConfig(
            model = model.absolutePath,
            tokens = tokens.absolutePath,
            dataDir = dataDir.absolutePath
        )

        val modelConfig = OfflineTtsModelConfig(
            vits = vits,
            numThreads = 2,
            debug = false
        )

        val config = OfflineTtsConfig(
            model = modelConfig,
            maxNumSentences = 1,
            silenceScale = 0.2f
        )

        val tts = OfflineTts(config = config)
        try {
            val chunks = splitText(text, 1800)
            val all = ArrayList<Float>()
            var sampleRate = tts.sampleRate()

            chunks.forEach { chunk ->
                val gen = GenerationConfig(
                    sid = 0,
                    speed = speed.coerceIn(0.5f, 2.0f),
                    silenceScale = 0.2f
                )
                val audio = tts.generateWithConfigAndCallback(
                    text = chunk,
                    config = gen
                ) { 1 }

                sampleRate = audio.sampleRate
                for (sample in audio.samples) all.add(sample)

                repeat((sampleRate * pauseMs.coerceIn(0, 2000) / 1000f).toInt()) {
                    all.add(0f)
                }
            }

            writeWav(output, all.toFloatArray(), sampleRate)
            return output
        } finally {
            tts.release()
        }
    }

    private fun splitText(text: String, maxChars: Int): List<String> {
        val normalized = text.replace("\r\n", "\n").trim()
        if (normalized.isEmpty()) return emptyList()
        if (normalized.length <= maxChars) return listOf(normalized)

        val paragraphs = normalized.split(Regex("\\n\\s*\\n"))
        val result = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            if (current.isNotBlank()) {
                result += current.toString().trim()
                current = StringBuilder()
            }
        }

        for (paragraph in paragraphs) {
            val p = paragraph.trim()
            if (p.isEmpty()) continue

            if (p.length <= maxChars) {
                if (current.length + p.length + 2 <= maxChars) {
                    if (current.isNotEmpty()) current.append("\n\n")
                    current.append(p)
                } else {
                    flush()
                    current.append(p)
                }
            } else {
                flush()
                var rest = p
                while (rest.length > maxChars) {
                    val cut = findCut(rest, maxChars)
                    result += rest.substring(0, cut).trim()
                    rest = rest.substring(cut).trim()
                }
                if (rest.isNotEmpty()) current.append(rest)
            }
        }
        flush()
        return result
    }

    private fun findCut(s: String, limit: Int): Int {
        val part = s.substring(0, min(limit, s.length))
        val candidates = listOf(
            part.lastIndexOf(". "),
            part.lastIndexOf("! "),
            part.lastIndexOf("? "),
            part.lastIndexOf("… "),
            part.lastIndexOf(", "),
            part.lastIndexOf(" ")
        )
        return candidates.maxOrNull()?.takeIf { it > limit * .55 }?.plus(1) ?: limit
    }

    private fun writeWav(file: File, samples: FloatArray, sampleRate: Int) {
        file.parentFile?.mkdirs()
        DataOutputStream(BufferedOutputStream(FileOutputStream(file))).use { out ->
            val dataSize = samples.size * 2
            out.writeBytes("RIFF")
            writeLEInt(out, 36 + dataSize)
            out.writeBytes("WAVE")
            out.writeBytes("fmt ")
            writeLEInt(out, 16)
            writeLEShort(out, 1) // PCM
            writeLEShort(out, 1) // mono
            writeLEInt(out, sampleRate)
            writeLEInt(out, sampleRate * 2)
            writeLEShort(out, 2)
            writeLEShort(out, 16)
            out.writeBytes("data")
            writeLEInt(out, dataSize)
            samples.forEach {
                writeLEShort(out, (it.coerceIn(-1f, 1f) * 32767f).toInt())
            }
        }
    }

    private fun writeLEInt(out: DataOutputStream, v: Int) {
        out.writeByte(v and 255)
        out.writeByte((v shr 8) and 255)
        out.writeByte((v shr 16) and 255)
        out.writeByte((v shr 24) and 255)
    }

    private fun writeLEShort(out: DataOutputStream, v: Int) {
        out.writeByte(v and 255)
        out.writeByte((v shr 8) and 255)
    }
}
