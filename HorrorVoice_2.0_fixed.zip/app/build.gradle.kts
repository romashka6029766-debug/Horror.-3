plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.neurovoiceoffline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.neurovoiceoffline"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")

    // Offline neural TTS engine. No paid API.
    implementation("com.github.k2-fsa:sherpa-onnx:v1.13.4")

    // Used only to unpack the free Piper/Sherpa voice archive.
    implementation("org.apache.commons:commons-compress:1.27.1")
}
